# Technical notes

## Why the overlay cannot apply global image effects

`WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY` creates a normal application overlay window. It can display controls above activity windows, but Android does not expose a public per-app API for a normal app to insert a post-processing shader into another process's Surface/SurfaceFlinger composition. An overlay cannot rewrite the pixels below itself.

A MediaProjection capture-and-replace workaround is not equivalent: it needs explicit user consent, is revocable, may receive black/blank content for protected surfaces, introduces an extra capture/render path, and cannot guarantee zero latency or zero frame cost. It is deliberately not used as a hidden substitute here.

## Why “DLSS 5 / fake 2K HDR / zero FPS loss” is not implemented for games

DLSS is a vendor rendering technology integrated into a supported rendering pipeline. A third-party Android app cannot create missing game render data or inject a DLSS-like temporal reconstruction pipeline into arbitrary games from outside. The included 2K-labelled control is a clearly labelled image-lab demonstration: pixel processing followed by standard bitmap interpolation.

## Frame pacing vs external-game FPS

The benchmark uses Choreographer callbacks inside this application's visible Activity. That produces a genuine measurement for this app's frame callback cadence. It does not read an unrelated game's render loop. Display refresh rate (Hz) is read separately from Android's Display API.

For real external-game frame timestamps, an implementation must use a privileged and device-specific route such as shell/ADB or root and identify the correct SurfaceFlinger layer for that game. Permissions and layer naming can differ by Android release and OEM; the app intentionally reports this as unsupported instead of displaying invented numbers.
