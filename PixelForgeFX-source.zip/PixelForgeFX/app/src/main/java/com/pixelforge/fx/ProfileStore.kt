package com.pixelforge.fx

import android.content.Context

/** Stores per-package visual profiles. Values are for the built-in preview, not other apps' pixels. */
data class FxProfile(
    val saturation: Int = 100, // 0..200; 100 = unchanged
    val exposure: Int = 0,     // -100..100; mapped to -1..+1 EV
    val sharpen: Int = 0,      // 0..100
    val shadows: Int = 0       // -100..100
)

object ProfileStore {
    private const val PREFS = "pixelforge_profiles"
    private fun key(packageName: String, field: String) = "$packageName::$field"

    fun read(context: Context, packageName: String): FxProfile {
        val p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        return FxProfile(
            saturation = p.getInt(key(packageName, "sat"), 100).coerceIn(0, 200),
            exposure = p.getInt(key(packageName, "exp"), 0).coerceIn(-100, 100),
            sharpen = p.getInt(key(packageName, "sharp"), 0).coerceIn(0, 100),
            shadows = p.getInt(key(packageName, "shadow"), 0).coerceIn(-100, 100)
        )
    }

    fun write(context: Context, packageName: String, profile: FxProfile) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putInt(key(packageName, "sat"), profile.saturation.coerceIn(0, 200))
            .putInt(key(packageName, "exp"), profile.exposure.coerceIn(-100, 100))
            .putInt(key(packageName, "sharp"), profile.sharpen.coerceIn(0, 100))
            .putInt(key(packageName, "shadow"), profile.shadows.coerceIn(-100, 100))
            .apply()
    }

    fun selectedPackage(context: Context): String =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("selected_package", "") ?: ""

    fun setSelectedPackage(context: Context, packageName: String) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString("selected_package", packageName).apply()
    }
}
