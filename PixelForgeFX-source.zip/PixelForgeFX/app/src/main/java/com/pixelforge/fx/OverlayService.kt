package com.pixelforge.fx

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast

class OverlayService : Service() {
    companion object {
        const val ACTION_SHOW = "com.pixelforge.fx.SHOW_OVERLAY"
        const val ACTION_HIDE = "com.pixelforge.fx.HIDE_OVERLAY"
        const val EXTRA_PACKAGE = "target_package"
        private const val CHANNEL = "pixelforge_overlay"
        private const val NOTIFICATION_ID = 7301
    }

    private lateinit var windowManager: WindowManager
    private var root: LinearLayout? = null
    private var panel: LinearLayout? = null
    private var params: WindowManager.LayoutParams? = null
    private var targetPackage: String = ""
    private var expanded = false
    private var profile = FxProfile()

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        targetPackage = intent?.getStringExtra(EXTRA_PACKAGE)?.takeIf { it.isNotBlank() }
            ?: ProfileStore.selectedPackage(this)
        if (targetPackage.isBlank()) {
            stopSelf()
            return START_NOT_STICKY
        }
        profile = ProfileStore.read(this, targetPackage)
        startAsForeground()
        if (intent?.action == ACTION_HIDE) {
            removeOverlay()
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "صلاحية الظهور فوق التطبيقات غير مفعّلة", Toast.LENGTH_SHORT).show()
            stopSelf()
            return START_NOT_STICKY
        }
        if (root == null) showOverlay() else refreshPanel()
        return START_STICKY
    }

    private fun startAsForeground() {
        val openIntent = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notification = if (Build.VERSION.SDK_INT >= 26) {
            Notification.Builder(this, CHANNEL)
                .setContentTitle("PixelForge FX يعمل")
                .setContentText("لوحة التحكم العائمة جاهزة — المؤثرات مخصصة للمعاينة")
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .setContentIntent(openIntent)
                .setOngoing(true)
                .build()
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
                .setContentTitle("PixelForge FX يعمل")
                .setContentText("لوحة التحكم العائمة جاهزة")
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .setContentIntent(openIntent)
                .setOngoing(true)
                .build()
        }
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(CHANNEL, "PixelForge floating panel", NotificationManager.IMPORTANCE_LOW)
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
        }
    }

    private fun showOverlay() {
        val windowType = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
        params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            windowType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = Ui.dp(this@OverlayService, 12)
            y = Ui.dp(this@OverlayService, 140)
        }

        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply { setColor(0xEE12192B.toInt()); cornerRadius = Ui.dp(this@OverlayService, 18).toFloat(); setStroke(Ui.dp(this@OverlayService, 1), Ui.ACCENT) }
            setPadding(Ui.dp(this@OverlayService, 9), Ui.dp(this@OverlayService, 8), Ui.dp(this@OverlayService, 9), Ui.dp(this@OverlayService, 8))
        }
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val badge = Ui.button(this, if (expanded) "FX ▾" else "FX", true).apply {
            setOnClickListener { expanded = !expanded; refreshPanel() }
            minWidth = Ui.dp(this@OverlayService, 52)
        }
        top.addView(badge)
        val title = Ui.text(this, "  PixelForge", 12f, Ui.TEXT, true)
        top.addView(title)
        val close = Ui.button(this, "×", false).apply {
            minWidth = Ui.dp(this@OverlayService, 40)
            setOnClickListener { removeOverlay(); stopForeground(STOP_FOREGROUND_REMOVE); stopSelf() }
        }
        top.addView(close)
        top.setOnTouchListener(DragListener())
        root?.addView(top)
        panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root?.addView(panel)
        refreshPanel()
        try {
            windowManager.addView(root, params)
        } catch (_: Exception) {
            root = null
            stopSelf()
        }
    }

    private inner class DragListener : View.OnTouchListener {
        private var startX = 0
        private var startY = 0
        private var touchX = 0f
        private var touchY = 0f
        override fun onTouch(v: View, event: MotionEvent): Boolean {
            val p = params ?: return false
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = p.x; startY = p.y
                    touchX = event.rawX; touchY = event.rawY
                    return true
                }
                MotionEvent.ACTION_MOVE -> {
                    p.x = startX - (event.rawX - touchX).toInt()
                    p.y = startY + (event.rawY - touchY).toInt()
                    try { root?.let { windowManager.updateViewLayout(it, p) } } catch (_: Exception) { }
                    return true
                }
            }
            return false
        }
    }

    private fun refreshPanel() {
        val box = panel ?: return
        box.removeAllViews()
        val header = Ui.text(this, if (expanded) "ملف التطبيق المحدد" else "اضغط FX لعرض الأدوات", 11f, Ui.MUTED, true)
        box.addView(header)
        if (!expanded) return
        box.addView(makeSlider("التشبّع", profile.saturation, 0, 200, "${profile.saturation}%") { profile = profile.copy(saturation = it) })
        box.addView(makeSlider("التعريض", profile.exposure, -100, 100, "${profile.exposure}") { profile = profile.copy(exposure = it) })
        box.addView(makeSlider("الحدّة", profile.sharpen, 0, 100, "${profile.sharpen}%") { profile = profile.copy(sharpen = it) })
        box.addView(makeSlider("الظلال", profile.shadows, -100, 100, "${profile.shadows}") { profile = profile.copy(shadows = it) })
        val note = Ui.text(this, "هذه القيم تُحفظ للمعاينة داخل التطبيق، ولا تغيّر بكسلات اللعبة الخارجية.", 10f, Ui.WARN)
        box.addView(note)
        val preview = Ui.button(this, "Fake 2K HDR — معاينة", true).apply {
            setOnClickListener {
                val i = Intent(this@OverlayService, PreviewActivity::class.java)
                    .putExtra("package_name", targetPackage)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(i)
            }
        }
        box.addView(preview)
        val reader = Ui.button(this, "قارئ الإطارات", false).apply {
            setOnClickListener { startActivity(Intent(this@OverlayService, BenchmarkActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        }
        box.addView(reader)
        ProfileStore.write(this, targetPackage, profile)
    }

    private fun makeSlider(title: String, value: Int, min: Int, max: Int, display: String, changed: (Int) -> Unit): LinearLayout {
        val wrap = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, Ui.dp(this@OverlayService, 4), 0, Ui.dp(this@OverlayService, 4)) }
        val line = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        line.addView(Ui.text(this, title, 11f, Ui.TEXT, true), LinearLayout.LayoutParams(0, -2, 1f))
        val valText = Ui.text(this, display, 10f, Ui.TEAL)
        line.addView(valText)
        wrap.addView(line)
        val seek = SeekBar(this).apply {
            this.max = max - min
            progress = value - min
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                    val v = progress + min
                    valText.text = if (title == "التشبّع" || title == "الحدّة") "${v}%" else "$v"
                    if (fromUser) {
                        changed(v)
                        ProfileStore.write(this@OverlayService, targetPackage, profile)
                    }
                }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
        }
        wrap.addView(seek)
        return wrap
    }

    private fun removeOverlay() {
        root?.let { try { windowManager.removeView(it) } catch (_: Exception) { } }
        root = null
        panel = null
    }

    override fun onDestroy() {
        removeOverlay()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
