package com.pixelforge.fx

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Rect
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow

object DemoImage {
    fun create(width: Int = 640, height: Int = 360): Bitmap {
        val bmp = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        val sky = Paint(Paint.ANTI_ALIAS_FLAG)
        sky.shader = android.graphics.LinearGradient(0f, 0f, 0f, height.toFloat(), 0xFF13264B.toInt(), 0xFFEF9A72.toInt(), android.graphics.Shader.TileMode.CLAMP)
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), sky)
        val sun = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFFE0A0.toInt() }
        canvas.drawCircle(width * .76f, height * .30f, height * .105f, sun)
        drawMountain(canvas, width, height, 0.56f, 0xFF415E83.toInt(), .36f)
        drawMountain(canvas, width, height, 0.68f, 0xFF263C5E.toInt(), .54f)
        drawMountain(canvas, width, height, 0.80f, 0xFF182C48.toInt(), .72f)
        val lake = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF1A5366.toInt() }
        canvas.drawRect(0f, height * .72f, width.toFloat(), height.toFloat(), lake)
        val reflection = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFEDB47F.toInt(); alpha = 110 }
        canvas.drawOval(width * .62f, height * .74f, width * .91f, height * .84f, reflection)
        val shore = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF102B34.toInt() }
        val shorePath = Path().apply {
            moveTo(0f, height * .79f); cubicTo(width * .22f, height * .68f, width * .39f, height * .90f, width * .58f, height * .80f)
            lineTo(width.toFloat(), height * .84f); lineTo(width.toFloat(), height.toFloat()); lineTo(0f, height.toFloat()); close()
        }
        canvas.drawPath(shorePath, shore)
        val tree = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF0C1D22.toInt() }
        for (i in 0..8) {
            val x = width * (i / 8f)
            val base = height * (.92f + (i % 3) * .018f)
            canvas.drawRect(x - width * .006f, base - height * .19f, x + width * .006f, base, tree)
            canvas.drawCircle(x, base - height * .19f, height * .045f + (i % 2) * height * .012f, tree)
            canvas.drawCircle(x - width * .018f, base - height * .15f, height * .04f, tree)
            canvas.drawCircle(x + width * .018f, base - height * .15f, height * .04f, tree)
        }
        return bmp
    }

    private fun drawMountain(canvas: Canvas, w: Int, h: Int, baseY: Float, color: Int, shift: Float) {
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color = color }
        val path = Path().apply {
            moveTo(0f, h * baseY)
            lineTo(w * .20f, h * (shift - .08f))
            lineTo(w * .34f, h * (shift + .05f))
            lineTo(w * .58f, h * (shift - .22f))
            lineTo(w * .78f, h * (shift + .06f))
            lineTo(w.toFloat(), h * (baseY - .02f))
            lineTo(w.toFloat(), h.toFloat()); lineTo(0f, h.toFloat()); close()
        }
        canvas.drawPath(path, p)
    }
}

object BitmapFx {
    fun apply(input: Bitmap, profile: FxProfile, hdrPreview: Boolean = false): Bitmap {
        val source = if (input.width > 900 || input.height > 900) {
            val scale = min(900f / input.width, 900f / input.height)
            Bitmap.createScaledBitmap(input, max(1, (input.width * scale).toInt()), max(1, (input.height * scale).toInt()), true)
        } else input
        val w = source.width
        val h = source.height
        val count = w * h
        val original = IntArray(count)
        source.getPixels(original, 0, w, 0, 0, w, h)
        val base = IntArray(count)
        val exposure = 2.0.pow(profile.exposure.coerceIn(-100, 100) / 100.0).toFloat()
        val saturation = profile.saturation.coerceIn(0, 200) / 100f
        val shadow = profile.shadows.coerceIn(-100, 100) / 100f
        for (i in 0 until count) {
            val c = original[i]
            var r = Color.red(c).toFloat() * exposure
            var g = Color.green(c).toFloat() * exposure
            var b = Color.blue(c).toFloat() * exposure
            val lum = (0.2126f * r + 0.7152f * g + 0.0722f * b).coerceIn(0f, 255f)
            r = lum + (r - lum) * saturation
            g = lum + (g - lum) * saturation
            b = lum + (b - lum) * saturation
            val shadowWeight = (1f - lum / 255f).coerceIn(0f, 1f).pow(2)
            val shadowShift = if (shadow >= 0) shadow * 66f * shadowWeight else shadow * 54f * shadowWeight
            r = (r + shadowShift).coerceIn(0f, 255f)
            g = (g + shadowShift).coerceIn(0f, 255f)
            b = (b + shadowShift).coerceIn(0f, 255f)
            if (hdrPreview) {
                fun tone(v: Float) = (v * 1.10f + (v * (255f - v) / 255f) * .18f).coerceIn(0f, 255f)
                r = tone(r); g = tone(g); b = tone(b)
            }
            base[i] = Color.argb(Color.alpha(c), r.toInt(), g.toInt(), b.toInt())
        }
        val amount = profile.sharpen.coerceIn(0, 100) / 100f * 1.15f
        if (amount > 0f && w > 2 && h > 2) {
            val sharpened = base.copyOf()
            for (y in 1 until h - 1) for (x in 1 until w - 1) {
                val i = y * w + x
                val c = base[i]
                val l = base[i - 1]; val r = base[i + 1]; val u = base[i - w]; val d = base[i + w]
                fun sharpen(ch: (Int) -> Int): Int {
                    val center = ch(c).toFloat()
                    val avg = (ch(l) + ch(r) + ch(u) + ch(d)) / 4f
                    return (center + (center - avg) * amount).toInt().coerceIn(0, 255)
                }
                sharpened[i] = Color.argb(Color.alpha(c), sharpen { Color.red(it) }, sharpen { Color.green(it) }, sharpen { Color.blue(it) })
            }
            for (x in 0 until w) {
                sharpened[x] = base[x]
                sharpened[(h - 1) * w + x] = base[(h - 1) * w + x]
            }
            for (y in 0 until h) {
                sharpened[y * w] = base[y * w]
                sharpened[y * w + w - 1] = base[y * w + w - 1]
            }
            val output = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            output.setPixels(sharpened, 0, w, 0, 0, w, h)
            if (source !== input) source.recycle()
            return output
        }
        val output = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        output.setPixels(base, 0, w, 0, 0, w, h)
        if (source !== input) source.recycle()
        return output
    }

    fun fake2k(input: Bitmap, profile: FxProfile): Bitmap {
        // Process at the input's practical preview size first, then create a 2560px-wide
        // interpolated output. This is a preview scaler, not temporal/AI game upscaling.
        val enhanced = apply(input, profile.copy(
            saturation = (profile.saturation * 1.08f).toInt().coerceAtMost(200),
            sharpen = max(profile.sharpen, 25)
        ), true)
        val outHeight = max(1, (2560f * enhanced.height / enhanced.width).toInt())
        val enlarged = Bitmap.createScaledBitmap(enhanced, 2560, outHeight, true)
        if (enlarged !== enhanced) enhanced.recycle()
        return enlarged
    }
}
