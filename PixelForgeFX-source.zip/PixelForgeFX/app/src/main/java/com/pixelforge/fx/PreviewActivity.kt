package com.pixelforge.fx

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger
import kotlin.math.max

class PreviewActivity : Activity() {
    companion object { private const val PICK_IMAGE = 4102 }

    private lateinit var imageView: ImageView
    private lateinit var info: TextView
    private lateinit var saturationLabel: TextView
    private lateinit var exposureLabel: TextView
    private lateinit var sharpenLabel: TextView
    private lateinit var shadowsLabel: TextView
    private val executor = Executors.newSingleThreadExecutor()
    private val handler = Handler(Looper.getMainLooper())
    private val renderToken = AtomicInteger(0)
    private var original: Bitmap? = null
    private var shown: Bitmap? = null
    private var profile = FxProfile()
    private var packageForProfile = "general"
    private var hdrMode = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Ui.BG
        window.navigationBarColor = Ui.BG
        if (android.os.Build.VERSION.SDK_INT >= 30) window.setDecorFitsSystemWindows(true)
        packageForProfile = intent.getStringExtra("package_name")
            ?: ProfileStore.selectedPackage(this).ifBlank { "general" }
        profile = ProfileStore.read(this, packageForProfile)
        original = DemoImage.create()
        buildUi()
        renderImage(false)
    }

    private fun buildUi() {
        val scroll = ScrollView(this).apply { setBackgroundColor(Ui.BG) }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(Ui.dp(this@PreviewActivity, 16), Ui.dp(this@PreviewActivity, 18), Ui.dp(this@PreviewActivity, 16), Ui.dp(this@PreviewActivity, 28))
        }
        scroll.addView(root)
        setContentView(scroll)
        root.addView(Ui.text(this, "PIXELFORGE / IMAGE LAB", 11f, Ui.TEAL, true))
        root.addView(Ui.text(this, "معمل المؤثرات", 24f, Ui.TEXT, true))
        root.addView(Ui.text(this, "هذه معاينة حقيقية لمعالجة صورة تختارها، وليست فلترًا يُحقن في سطح لعبة أخرى.", 12f, Ui.MUTED))
        gap(root, 14)

        imageView = ImageView(this).apply {
            scaleType = ImageView.ScaleType.FIT_CENTER
            adjustViewBounds = true
            background = GradientDrawable().apply { setColor(0xFF070A11.toInt()); cornerRadius = Ui.dp(this@PreviewActivity, 16).toFloat() }
            setPadding(Ui.dp(this@PreviewActivity, 4), Ui.dp(this@PreviewActivity, 4), Ui.dp(this@PreviewActivity, 4), Ui.dp(this@PreviewActivity, 4))
        }
        root.addView(imageView, LinearLayout.LayoutParams(-1, Ui.dp(this, 220)))
        info = Ui.text(this, "معاينة الصورة التجريبية", 11f, Ui.MUTED)
        root.addView(info)
        gap(root, 12)

        val imageButtons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        imageButtons.addView(Ui.button(this, "اختيار صورة", false).apply { setOnClickListener { pickImage() } }, LinearLayout.LayoutParams(0, Ui.dp(this, 46), 1f))
        imageButtons.addView(Ui.button(this, "إعادة ضبط", false).apply {
            setOnClickListener { profile = FxProfile(); saveProfile(); resetSeekbars(); hdrMode = false; renderImage(false) }
        }, LinearLayout.LayoutParams(0, Ui.dp(this, 46), 1f).apply { marginStart = Ui.dp(this@PreviewActivity, 8) })
        root.addView(imageButtons)
        gap(root, 14)

        val sliders = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply { setColor(Ui.CARD); cornerRadius = Ui.dp(this@PreviewActivity, 18).toFloat(); setStroke(Ui.dp(this@PreviewActivity, 1), 0xFF25304A.toInt()) }
            setPadding(Ui.dp(this@PreviewActivity, 14), Ui.dp(this@PreviewActivity, 12), Ui.dp(this@PreviewActivity, 14), Ui.dp(this@PreviewActivity, 12))
        }
        root.addView(Ui.text(this, "تعديلات الصورة", 16f, Ui.TEXT, true))
        saturationLabel = Ui.text(this, "التشبّع: ${profile.saturation}%", 12f, Ui.TEXT, true)
        exposureLabel = Ui.text(this, "التعريض: ${profile.exposure}", 12f, Ui.TEXT, true)
        sharpenLabel = Ui.text(this, "الحدّة: ${profile.sharpen}%", 12f, Ui.TEXT, true)
        shadowsLabel = Ui.text(this, "الظلال: ${profile.shadows}", 12f, Ui.TEXT, true)
        sliders.addView(saturationLabel); sliders.addView(makeSeek(200, profile.saturation) { v -> profile = profile.copy(saturation = v); saturationLabel.text = "التشبّع: ${v}%" })
        sliders.addView(exposureLabel); sliders.addView(makeSeek(200, profile.exposure + 100) { v -> profile = profile.copy(exposure = v - 100); exposureLabel.text = "التعريض: ${v - 100}" })
        sliders.addView(sharpenLabel); sliders.addView(makeSeek(100, profile.sharpen) { v -> profile = profile.copy(sharpen = v); sharpenLabel.text = "الحدّة: ${v}%" })
        sliders.addView(shadowsLabel); sliders.addView(makeSeek(200, profile.shadows + 100) { v -> profile = profile.copy(shadows = v - 100); shadowsLabel.text = "الظلال: ${v - 100}" })
        root.addView(sliders)
        gap(root, 12)

        val hdr = Ui.button(this, "FAKE 2K HDR  •  تحسين تكبيري للمعاينة", true).apply {
            setOnClickListener {
                hdrMode = true
                info.text = "وضع عرض 2560×1440 للمعاينة فقط — تكبير واستيفاء + ضبط نغمي، ليس DLSS ولا يعالج لعبة خارجية."
                renderImage(true)
            }
        }
        root.addView(hdr, LinearLayout.LayoutParams(-1, Ui.dp(this, 52)))
        gap(root, 8)
        root.addView(Ui.text(this, "ملاحظة: لا يوجد زر يستطيع توليد تفاصيل حقيقية مفقودة أو ضمان صفر تكلفة أداء. رفع الدقة هنا يخص الصورة المعروضة داخل هذا المعمل فقط.", 11f, Ui.WARN))
    }

    private fun makeSeek(maxValue: Int, start: Int, changed: (Int) -> Unit): SeekBar {
        return SeekBar(this).apply {
            max = maxValue
            progress = start.coerceIn(0, maxValue)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    if (fromUser) {
                        changed(progress)
                        hdrMode = false
                        saveProfile()
                        renderDebounced()
                    }
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        }
    }

    private fun renderDebounced() {
        handler.removeCallbacksAndMessages(RENDER_TOKEN)
        handler.postAtTime({ renderImage(hdrMode) }, RENDER_TOKEN, android.os.SystemClock.uptimeMillis() + 130)
    }

    private fun renderImage(hdr: Boolean) {
        val src = original ?: return
        val token = renderToken.incrementAndGet()
        val snapshot = profile
        executor.execute {
            val result = try {
                if (hdr) BitmapFx.fake2k(src, snapshot) else BitmapFx.apply(src, snapshot)
            } catch (_: OutOfMemoryError) {
                null
            } catch (_: Exception) {
                null
            }
            runOnUiThread {
                if (token != renderToken.get()) {
                    result?.recycle()
                    return@runOnUiThread
                }
                if (result != null) {
                    val previous = shown
                    shown = result
                    imageView.setImageBitmap(result)
                    if (previous != null && previous !== original && !previous.isRecycled) previous.recycle()
                    if (!hdr) info.text = "معاينة محسّنة — ملف: $packageForProfile"
                } else {
                    Toast.makeText(this, "تعذر معالجة الصورة؛ جرّب صورة أصغر", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun pickImage() {
        val intent = Intent(Intent.ACTION_GET_CONTENT).apply { type = "image/*"; addCategory(Intent.CATEGORY_OPENABLE) }
        @Suppress("DEPRECATION")
        startActivityForResult(Intent.createChooser(intent, "اختر صورة للمعاينة"), PICK_IMAGE)
    }

    @Deprecated("Image picker result")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == PICK_IMAGE && resultCode == RESULT_OK) {
            val uri: Uri = data?.data ?: return
            try {
                val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
                var sample = 1
                while (opts.outWidth / sample > 1000 || opts.outHeight / sample > 1000) sample *= 2
                val decoded = BitmapFactory.Options().apply { inSampleSize = max(1, sample); inPreferredConfig = Bitmap.Config.ARGB_8888 }
                val bitmap = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, decoded) }
                if (bitmap != null) {
                    original?.takeIf { it !== shown && !it.isRecycled }?.recycle()
                    original = bitmap
                    hdrMode = false
                    info.text = "تم تحميل صورتك — تُعالَج محليًا على الجهاز"
                    renderImage(false)
                }
            } catch (_: Exception) {
                Toast.makeText(this, "لم أتمكن من فتح هذه الصورة", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun saveProfile() = ProfileStore.write(this, packageForProfile, profile)

    private fun resetSeekbars() {
        // Rebuild screen so each seekbar reflects the reset values.
        buildUi()
    }

    private fun gap(parent: LinearLayout, d: Int) { parent.addView(View(this), LinearLayout.LayoutParams(1, Ui.dp(this, d))) }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(RENDER_TOKEN)
        executor.shutdownNow()
        shown?.takeIf { it !== original && !it.isRecycled }?.recycle()
        original?.takeIf { !it.isRecycled }?.recycle()
        super.onDestroy()
    }

}
