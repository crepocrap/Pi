package com.pixelforge.fx

import android.app.Activity
import android.hardware.display.DisplayManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Choreographer
import android.view.Display
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import kotlin.math.roundToInt

class BenchmarkActivity : Activity(), Choreographer.FrameCallback {
    private lateinit var fpsText: TextView
    private lateinit var hzText: TextView
    private lateinit var frameTimeText: TextView
    private lateinit var jankText: TextView
    private lateinit var statusText: TextView
    private var running = false
    private var lastFrameNanos = 0L
    private var windowStartNanos = 0L
    private var frames = 0
    private var janky = 0
    private var minFrameMs = Double.MAX_VALUE
    private var maxFrameMs = 0.0
    private var sumFrameMs = 0.0
    private var sampleCount = 0
    private val handler = Handler(Looper.getMainLooper())
    private val displayManager by lazy { getSystemService(DISPLAY_SERVICE) as DisplayManager }
    private val displayListener = object : DisplayManager.DisplayListener {
        override fun onDisplayAdded(displayId: Int) {}
        override fun onDisplayRemoved(displayId: Int) {}
        override fun onDisplayChanged(displayId: Int) { updateRefreshRate() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Ui.BG
        window.navigationBarColor = Ui.BG
        if (android.os.Build.VERSION.SDK_INT >= 30) window.setDecorFitsSystemWindows(true)
        val scroll = ScrollView(this).apply { setBackgroundColor(Ui.BG) }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(Ui.dp(this@BenchmarkActivity, 18), Ui.dp(this@BenchmarkActivity, 22), Ui.dp(this@BenchmarkActivity, 18), Ui.dp(this@BenchmarkActivity, 28))
        }
        scroll.addView(root)
        setContentView(scroll)

        root.addView(Ui.text(this, "PIXELFORGE / PERFORMANCE", 11f, Ui.TEAL, true))
        root.addView(Ui.text(this, "قارئ الإطارات", 25f, Ui.TEXT, true))
        root.addView(Ui.text(this, "قياس حيّ لجدولة إطارات هذه الشاشة داخل PixelForge.", 13f, Ui.MUTED))
        gap(root, 16)

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = android.graphics.drawable.GradientDrawable().apply { setColor(Ui.CARD); cornerRadius = Ui.dp(this@BenchmarkActivity, 20).toFloat(); setStroke(Ui.dp(this@BenchmarkActivity, 1), 0xFF25304A.toInt()) }
            setPadding(Ui.dp(this@BenchmarkActivity, 18), Ui.dp(this@BenchmarkActivity, 18), Ui.dp(this@BenchmarkActivity, 18), Ui.dp(this@BenchmarkActivity, 18))
        }
        fpsText = metric("FPS المقاس", "—")
        hzText = metric("تردد الشاشة", "—")
        frameTimeText = metric("متوسط زمن الإطار", "—")
        jankText = metric("إطارات متأخرة في العينة", "—")
        card.addView(fpsText); card.addView(hzText); card.addView(frameTimeText); card.addView(jankText)
        root.addView(card)
        gap(root, 14)
        statusText = Ui.text(this, "جارٍ التهيئة…", 12f, Ui.MUTED)
        root.addView(statusText)
        root.addView(Ui.button(this, "إيقاف / بدء القياس", true).apply { setOnClickListener { toggle() } }, LinearLayout.LayoutParams(-1, Ui.dp(this, 50)))
        gap(root, 14)
        val caution = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = android.graphics.drawable.GradientDrawable().apply { setColor(0xFF2D2418.toInt()); cornerRadius = Ui.dp(this@BenchmarkActivity, 16).toFloat() }
            setPadding(Ui.dp(this@BenchmarkActivity, 14), Ui.dp(this@BenchmarkActivity, 14), Ui.dp(this@BenchmarkActivity, 14), Ui.dp(this@BenchmarkActivity, 14))
        }
        caution.addView(Ui.text(this, "هذه ليست FPS اللعبة المفتوحة بالخلفية", 14f, Ui.WARN, true))
        caution.addView(Ui.text(this, "قياس FPS لتطبيق آخر يحتاج بيانات SurfaceFlinger بصلاحية shell عبر Shizuku/ADB أو root، وقد تختلف واجهته حسب الشركة وإصدار أندرويد. لا نعرض رقمًا تخمينيًا على أنه قياس اللعبة.", 12f, Ui.TEXT))
        root.addView(caution)
        gap(root, 12)
        root.addView(Ui.text(this, "الحد الأقصى النظري يساوي تردد الشاشة (مثل 60 أو 120Hz)، لكن تردد الشاشة لا يثبت أن اللعبة تنتج العدد نفسه من الإطارات.", 11f, Ui.MUTED))
        updateRefreshRate()
    }

    private fun metric(label: String, value: String): TextView = Ui.text(this, "$label\n$value", 17f, Ui.TEXT, true).apply {
        setPadding(0, Ui.dp(this@BenchmarkActivity, 8), 0, Ui.dp(this@BenchmarkActivity, 8))
    }

    private fun updateRefreshRate() {
        val display = getDefaultDisplayCompat()
        val hz = display?.refreshRate ?: 0f
        hzText.text = "تردد الشاشة\n${hz.roundToInt()} Hz"
    }

    private fun toggle() {
        if (running) {
            running = false
            Choreographer.getInstance().removeFrameCallback(this)
            statusText.text = "تم إيقاف القياس."
        } else {
            resetCounters()
            running = true
            statusText.text = "القياس جارٍ — إبقِ هذه الشاشة في المقدمة."
            Choreographer.getInstance().postFrameCallback(this)
        }
    }

    private fun resetCounters() {
        lastFrameNanos = 0L
        windowStartNanos = 0L
        frames = 0; janky = 0; minFrameMs = Double.MAX_VALUE; maxFrameMs = 0.0; sumFrameMs = 0.0; sampleCount = 0
        fpsText.text = "FPS المقاس\n—"
        frameTimeText.text = "متوسط زمن الإطار\n—"
        jankText.text = "إطارات متأخرة في العينة\n—"
    }

    override fun doFrame(frameTimeNanos: Long) {
        if (!running) return
        if (windowStartNanos == 0L) windowStartNanos = frameTimeNanos
        if (lastFrameNanos != 0L) {
            val ms = (frameTimeNanos - lastFrameNanos) / 1_000_000.0
            if (ms > 0 && ms < 1000) {
                frames++
                sumFrameMs += ms
                sampleCount++
                minFrameMs = minOf(minFrameMs, ms)
                maxFrameMs = maxOf(maxFrameMs, ms)
                val hz = currentHz().coerceAtLeast(30f)
                val expectedMs = 1000.0 / hz
                if (ms > expectedMs * 1.5) janky++
            }
        }
        lastFrameNanos = frameTimeNanos
        val elapsedMs = (frameTimeNanos - windowStartNanos) / 1_000_000.0
        if (elapsedMs >= 1000.0) {
            val fps = frames * 1000.0 / elapsedMs
            val average = if (sampleCount > 0) sumFrameMs / sampleCount else 0.0
            fpsText.text = "FPS المقاس\n${"%.1f".format(fps)}"
            frameTimeText.text = "متوسط زمن الإطار\n${"%.2f".format(average)} ms   •   min ${"%.2f".format(if (minFrameMs == Double.MAX_VALUE) 0.0 else minFrameMs)} / max ${"%.2f".format(maxFrameMs)}"
            jankText.text = "إطارات متأخرة في العينة\n$janky / $sampleCount"
            frames = 0; janky = 0; sumFrameMs = 0.0; sampleCount = 0; minFrameMs = Double.MAX_VALUE; maxFrameMs = 0.0
            windowStartNanos = frameTimeNanos
        }
        Choreographer.getInstance().postFrameCallback(this)
    }

    private fun currentHz(): Float {
        val display = getDefaultDisplayCompat()
        return display?.refreshRate ?: 60f
    }

    @Suppress("DEPRECATION")
    private fun getDefaultDisplayCompat(): Display? =
        if (android.os.Build.VERSION.SDK_INT >= 30) displayManager.getDisplay(Display.DEFAULT_DISPLAY) else windowManager.defaultDisplay

    override fun onResume() {
        super.onResume()
        displayManager.registerDisplayListener(displayListener, handler)
        if (!running) toggle()
    }

    override fun onPause() {
        displayManager.unregisterDisplayListener(displayListener)
        if (running) {
            running = false
            Choreographer.getInstance().removeFrameCallback(this)
        }
        super.onPause()
    }

    private fun gap(parent: LinearLayout, d: Int) { parent.addView(View(this), LinearLayout.LayoutParams(1, Ui.dp(this, d))) }
}
