package com.pixelforge.fx

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.View
import android.widget.Button
import android.widget.TextView

object Ui {
    const val BG = 0xFF0A0D16.toInt()
    const val CARD = 0xFF141B2B.toInt()
    const val ACCENT = 0xFF8B70FF.toInt()
    const val TEAL = 0xFF36D6C4.toInt()
    const val TEXT = 0xFFF4F6FF.toInt()
    const val MUTED = 0xFFAAB3C7.toInt()
    const val WARN = 0xFFFFC078.toInt()

    fun dp(context: Context, value: Int): Int = (value * context.resources.displayMetrics.density).toInt()

    fun rounded(color: Int, radiusDp: Int = 18, strokeColor: Int? = null): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = radiusDp.toFloat() * 3f // adjusted by the caller's density-independent scale where possible
            if (strokeColor != null) setStroke(1, strokeColor)
        }

    fun text(context: Context, value: String, size: Float = 14f, color: Int = TEXT, bold: Boolean = false): TextView =
        TextView(context).apply {
            text = value
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
            includeFontPadding = true
        }

    fun button(context: Context, value: String, filled: Boolean = true): Button =
        Button(context).apply {
            text = value
            textSize = 13f
            isAllCaps = false
            setTextColor(if (filled) Color.WHITE else TEXT)
            background = GradientDrawable().apply {
                setColor(if (filled) ACCENT else CARD)
                cornerRadius = dp(context, 14).toFloat()
                if (!filled) setStroke(dp(context, 1), 0xFF303A53.toInt())
            }
            minHeight = dp(context, 46)
            minimumHeight = dp(context, 46)
            stateListAnimator = null
            setPadding(dp(context, 14), 0, dp(context, 14), 0)
        }

    fun card(context: Context, view: View): View {
        view.background = GradientDrawable().apply {
            setColor(CARD)
            cornerRadius = dp(context, 18).toFloat()
            setStroke(dp(context, 1), 0xFF25304A.toInt())
        }
        view.setPadding(dp(context, 16), dp(context, 14), dp(context, 16), dp(context, 14))
        return view
    }
}
