package com.pixelforge.fx

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private data class AppEntry(val packageName: String, val label: String, val icon: android.graphics.drawable.Drawable)

    private lateinit var content: LinearLayout
    private lateinit var appList: LinearLayout
    private lateinit var search: EditText
    private var allLaunchable = emptyList<AppEntry>()
    private var chosenPackages = mutableSetOf<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Ui.BG
        window.navigationBarColor = Ui.BG
        if (android.os.Build.VERSION.SDK_INT >= 30) window.setDecorFitsSystemWindows(true)
        buildUi()
        refreshApps()
    }

    override fun onResume() {
        super.onResume()
        if (::content.isInitialized) refreshApps()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Ui.BG)
        }
        val scroll = ScrollView(this)
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(Ui.dp(this@MainActivity, 18), Ui.dp(this@MainActivity, 20), Ui.dp(this@MainActivity, 18), Ui.dp(this@MainActivity, 28))
        }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)

        val header = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        header.addView(Ui.text(this, "PIXELFORGE FX", 12f, Ui.TEAL, true))
        header.addView(Ui.text(this, "تحكّم بصري • لكل لعبة ملف مستقل", 23f, Ui.TEXT, true).apply {
            setPadding(0, Ui.dp(this@MainActivity, 5), 0, Ui.dp(this@MainActivity, 3))
        })
        header.addView(Ui.text(this, "لوحة عائمة ومعاينة مؤثرات ومراقبة أداء شفافة.", 13f, Ui.MUTED))
        content.addView(header)
        addGap(content, 18)

        val warning = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply { setColor(0xFF2D2418.toInt()); cornerRadius = Ui.dp(this@MainActivity, 16).toFloat() }
            setPadding(Ui.dp(this@MainActivity, 14), Ui.dp(this@MainActivity, 12), Ui.dp(this@MainActivity, 14), Ui.dp(this@MainActivity, 12))
        }
        warning.addView(Ui.text(this, "مهم: المؤثرات لا تُحقن داخل الألعاب", 14f, Ui.WARN, true))
        warning.addView(Ui.text(this, "أندرويد لا يتيح لتطبيق عادي تغيير صورة لعبة أخرى مباشرة. منزلقات اللعبة تحفظ ملفها وتتحكم بمعاينة الصور داخل PixelForge فقط.", 12f, Ui.TEXT))
        content.addView(warning)
        addGap(content, 18)

        val actionRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val add = Ui.button(this, "＋ إضافة تطبيق").apply { setOnClickListener { showAppPicker() } }
        actionRow.addView(add, LinearLayout.LayoutParams(0, Ui.dp(this, 48), 1f))
        val preview = Ui.button(this, "معاينة FX", false).apply {
            setOnClickListener { startActivity(Intent(this@MainActivity, PreviewActivity::class.java)) }
        }
        val previewParams = LinearLayout.LayoutParams(0, Ui.dp(this, 48), 1f).apply { marginStart = Ui.dp(this@MainActivity, 8) }
        actionRow.addView(preview, previewParams)
        content.addView(actionRow)
        addGap(content, 10)

        val bench = Ui.button(this, "قارئ الإطارات / Benchmark", false).apply {
            setOnClickListener { startActivity(Intent(this@MainActivity, BenchmarkActivity::class.java)) }
        }
        content.addView(bench, LinearLayout.LayoutParams(-1, Ui.dp(this, 48)))
        addGap(content, 20)

        content.addView(Ui.text(this, "تطبيقاتك المضافة", 18f, Ui.TEXT, true))
        content.addView(Ui.text(this, "اختر لعبة من القائمة، ثم افتحها من هنا لتظهر اللوحة العائمة.", 12f, Ui.MUTED))
        addGap(content, 8)
        search = EditText(this).apply {
            hint = "ابحث في التطبيقات المضافة…"
            setHintTextColor(Ui.MUTED)
            setTextColor(Ui.TEXT)
            textSize = 14f
            singleLine = true
            background = GradientDrawable().apply { setColor(Ui.CARD); cornerRadius = Ui.dp(this@MainActivity, 14).toFloat() }
            setPadding(Ui.dp(this@MainActivity, 14), 0, Ui.dp(this@MainActivity, 14), 0)
            addTextChangedListener(SimpleTextWatcher { renderAppList() })
        }
        content.addView(search, LinearLayout.LayoutParams(-1, Ui.dp(this, 48)))
        addGap(content, 10)
        appList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(appList)
        addGap(content, 18)

        val footer = Ui.text(this, "Fake 2K HDR: وضع تجريبي للمعاينة فقط؛ لا يصنع تفاصيل DLSS ولا يرفع دقة اللعبة الخارجية.\n\nلا نطلب صلاحيات قراءة الشاشة أو الميكروفون أو الملفات بلا حاجة.", 11f, Ui.MUTED)
        content.addView(footer)
    }

    private fun refreshApps() {
        val pm = packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        allLaunchable = pm.queryIntentActivities(intent, PackageManager.MATCH_ALL)
            .mapNotNull { ri ->
                val pkg = ri.activityInfo?.packageName ?: return@mapNotNull null
                if (pkg == packageName) return@mapNotNull null
                AppEntry(pkg, ri.loadLabel(pm).toString(), ri.loadIcon(pm))
            }
            .distinctBy { it.packageName }
            .sortedBy { it.label.lowercase() }
        chosenPackages = getSharedPreferences("pixelforge_apps", MODE_PRIVATE)
            .getStringSet("chosen", emptySet())?.toMutableSet() ?: mutableSetOf()
        renderAppList()
    }

    private fun showAppPicker() {
        if (allLaunchable.isEmpty()) refreshApps()
        val labels = allLaunchable.map { it.label }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("إضافة تطبيق أو لعبة")
            .setItems(labels) { _, which ->
                val selected = allLaunchable[which]
                chosenPackages.add(selected.packageName)
                getSharedPreferences("pixelforge_apps", MODE_PRIVATE).edit()
                    .putStringSet("chosen", chosenPackages.toSet()).apply()
                ProfileStore.setSelectedPackage(this, selected.packageName)
                renderAppList()
                Toast.makeText(this, "تمت إضافة ${selected.label}", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    private fun renderAppList() {
        if (!::appList.isInitialized) return
        appList.removeAllViews()
        val query = if (::search.isInitialized) search.text.toString().trim().lowercase() else ""
        val apps = allLaunchable.filter { it.packageName in chosenPackages && it.label.lowercase().contains(query) }
        if (apps.isEmpty()) {
            val empty = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                background = GradientDrawable().apply { setColor(Ui.CARD); cornerRadius = Ui.dp(this@MainActivity, 18).toFloat() }
                setPadding(Ui.dp(this@MainActivity, 20), Ui.dp(this@MainActivity, 26), Ui.dp(this@MainActivity, 20), Ui.dp(this@MainActivity, 26))
            }
            empty.addView(Ui.text(this, "لم تضف أي تطبيق بعد", 15f, Ui.TEXT, true))
            empty.addView(Ui.text(this, "اضغط «إضافة تطبيق» واختر لعبة أو تطبيقًا.", 12f, Ui.MUTED))
            appList.addView(empty)
            return
        }
        apps.forEach { app ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                background = GradientDrawable().apply { setColor(Ui.CARD); cornerRadius = Ui.dp(this@MainActivity, 18).toFloat(); setStroke(Ui.dp(this@MainActivity, 1), 0xFF25304A.toInt()) }
                setPadding(Ui.dp(this@MainActivity, 14), Ui.dp(this@MainActivity, 12), Ui.dp(this@MainActivity, 14), Ui.dp(this@MainActivity, 12))
            }
            val heading = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            val icon = ImageView(this).apply { setImageDrawable(app.icon) }
            heading.addView(icon, LinearLayout.LayoutParams(Ui.dp(this, 42), Ui.dp(this, 42)))
            val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            info.addView(Ui.text(this, app.label, 15f, Ui.TEXT, true))
            info.addView(Ui.text(this, app.packageName, 10f, Ui.MUTED))
            val infoParams = LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = Ui.dp(this@MainActivity, 12) }
            heading.addView(info, infoParams)
            val remove = Ui.button(this, "×", false).apply {
                minWidth = Ui.dp(this@MainActivity, 42)
                setOnClickListener {
                    chosenPackages.remove(app.packageName)
                    getSharedPreferences("pixelforge_apps", MODE_PRIVATE).edit().putStringSet("chosen", chosenPackages.toSet()).apply()
                    renderAppList()
                }
            }
            heading.addView(remove)
            card.addView(heading)
            addGap(card, 10)
            val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            val launch = Ui.button(this, "فتح مع اللوحة", true).apply {
                setOnClickListener { launchWithOverlay(app.packageName) }
            }
            actions.addView(launch, LinearLayout.LayoutParams(0, Ui.dp(this, 44), 1f))
            val profile = Ui.button(this, "الملف", false).apply {
                setOnClickListener {
                    ProfileStore.setSelectedPackage(this@MainActivity, app.packageName)
                    startActivity(Intent(this@MainActivity, PreviewActivity::class.java).putExtra("package_name", app.packageName))
                }
            }
            val profileParams = LinearLayout.LayoutParams(0, Ui.dp(this, 44), 0.65f).apply { marginStart = Ui.dp(this@MainActivity, 8) }
            actions.addView(profile, profileParams)
            card.addView(actions)
            val params = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = Ui.dp(this@MainActivity, 10) }
            appList.addView(card, params)
        }
    }

    private fun launchWithOverlay(packageName: String) {
        ProfileStore.setSelectedPackage(this, packageName)
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "اسمح بالظهور فوق التطبيقات لتفعيل اللوحة العائمة", Toast.LENGTH_LONG).show()
            val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${this.packageName}"))
            @Suppress("DEPRECATION")
            startActivityForResult(intent, 72)
            return
        }
        val service = Intent(this, OverlayService::class.java).apply {
            action = OverlayService.ACTION_SHOW
            putExtra(OverlayService.EXTRA_PACKAGE, packageName)
        }
        try {
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(service) else startService(service)
        } catch (_: Exception) {
            Toast.makeText(this, "تعذر تشغيل اللوحة؛ تحقق من قيود الشركة المصنّعة", Toast.LENGTH_LONG).show()
        }
        packageManager.getLaunchIntentForPackage(packageName)?.let { startActivity(it) }
            ?: Toast.makeText(this, "لم أعثر على اختصار تشغيل لهذا التطبيق", Toast.LENGTH_SHORT).show()
    }

    @Deprecated("Permission result is refreshed in onResume")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 72 && Settings.canDrawOverlays(this)) {
            val pkg = ProfileStore.selectedPackage(this)
            if (pkg.isNotBlank()) launchWithOverlay(pkg)
        }
    }

    private fun addGap(parent: LinearLayout, dp: Int) {
        parent.addView(View(this), LinearLayout.LayoutParams(1, Ui.dp(this, dp)))
    }
}
