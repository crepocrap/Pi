# No custom shrinking rules required for the first release.
