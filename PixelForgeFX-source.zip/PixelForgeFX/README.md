# PixelForge FX (Android)

**PixelForge FX** is an Android starter app for per-app visual profiles, a floating quick panel, local image-effect preview, and a transparent frame-pacing reader.

> **Important technical boundary:** A normal third-party Android app cannot post-process the pixels of another app/game globally. `TYPE_APPLICATION_OVERLAY` creates a floating window above apps; it is not a GPU post-processing layer. The saved saturation/exposure/sharpen/shadow values are therefore used by the built-in image lab and stored per selected package, but are not injected into the selected game's renderer. This project does not claim to implement DLSS, DLSS 5, real HDR, or zero-cost upscaling.

## Included

- Add installed launcher apps to a personal list.
- Independent saved profile per selected package.
- Floating `FX` panel over other apps (requires Android's “Display over other apps” permission).
- Local image lab: saturation, exposure, sharpen, and shadow lift/deepen.
- “Fake 2K HDR” preview: local tone adjustment + interpolation to a 2560-pixel-wide bitmap. It is not AI reconstruction and does not alter a game.
- Live `Choreographer` frame-pacing measurement for the PixelForge screen itself, plus actual display refresh rate. It explicitly does not label this as the FPS of a game running behind it.
- GitHub Actions workflow that builds a signed debug APK automatically.

## Build the APK on GitHub

1. Create a new GitHub repository (for example, `PixelForgeFX`).
2. Upload the contents of this folder to the repository root. Keep the `.github/workflows/build-apk.yml` file in place.
3. Push to the `main` or `master` branch, or open **Actions → Build PixelForge FX APK → Run workflow**.
4. Open the completed workflow run, scroll to **Artifacts**, and download `PixelForgeFX-debug-apk`.
5. Extract the artifact ZIP. Install the `.apk` on an Android device (you may need to allow installation from the browser/file manager you used).

The first build may take a few minutes while GitHub downloads the Android build tools and Gradle. This repository includes source code and a CI workflow; it does not contain a prebuilt APK because no Android SDK/Gradle build environment was available in this workspace.

## Run locally in Android Studio

- Android Studio with Android SDK Platform 35 installed.
- JDK 17.
- Open this folder as a project and run the `app` configuration, or run:

```bash
gradle --no-daemon :app:assembleDebug
```

Output: `app/build/outputs/apk/debug/app-debug.apk`.

## Permissions

The app only requests overlay permission when the user taps **Open with panel**. That permission is needed for the floating `FX` window. Android may still restrict overlay visibility on particular devices or over secure/system surfaces. No screen-capture, microphone, contacts, SMS, or broad storage permission is requested.

## Frame reader accuracy

The reader schedules callbacks using Android `Choreographer` and reports measured callback cadence while its own screen is visible. It separately reports the display refresh rate (Hz). Refresh rate is not equivalent to game FPS. Measuring a third-party game's actual SurfaceFlinger layer timestamps requires a device-specific privileged path (for example, shell access through Shizuku/ADB or root); this starter app does not fake that capability.

## Compatibility

- Minimum Android: 8.0 (API 26)
- Compile / target SDK: 35
- Application ID: `com.pixelforge.fx.debug` for the debug build
